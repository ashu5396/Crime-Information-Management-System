<!DOCTYPE html>
<html lang="en">
<head>
  <title>fleetcards Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script> 
<style>
.forcard
{
width:320px;
 border: 1px solid black;
}

</style>
</head>
<body>

<div class="container">
<div class="row">
<div class="col-lg-4 mt-2">
<img src="FleetCardsUSA_Logo_RGB_Logo.png" class="img-responsive  " alt="not found"/>
</div>
<div class="col-lg-4 mt-2">

</div>
<div class="col-lg-4 mt-2" >
<span >call now</span>
<span>1-800-633-3271</span>
<span >  
  <form class="form-inline" action="" >
    <input class="form-control mr-sm-2" type="text" placeholder="Search">
    <button class="btn btn-info" type="submit">Search</button>
  </form>
         </span>

</div>






<div class="col-lg-2  mt-3">
<a>what is fleet card</a>
</div>
<div class="col-lg-2 mt-3">
<a>compare cards</a>
</div>
<div class="col-lg-3 mt-3">
<a>talk to a fleet specialist </a>
</div>
<div class="col-lg-2 mt-3">
<a>FAQS</a>
</div>
<div class="col-lg-1 mt-3">

</div>
<div class="col-lg-2 mt-3">
<img src="chat-icon-orange-online@3x.png"  class="img-responsive   float-left" width="70px" width="70px" alt="not found"/><span><b>chat<Br>online</b></span>
</div>

</div>

</div>








<div class="container-fluid">

<div  style="height: 700px; width: 1400px; color: #ffffff;  
         background-image: url(home.jpg);
           background-repeat: no-repeat;">



<div class="container">
<div class="row col-lg-12 mt-5">
	
<div class="co1-lg-8 ">
<h1> <font color="perple"><b>FUEL CARDS THAT DRIVE RESULTS</b></font></h1>
<h1><font color="orange" ><i>Savings that go beyond the pump</i></font></h1>
</div>

<div class="col-lg-4 ml-5">
<img src="untitled.png"  class="img-responsive" width="100%" alt="not found"/>
</div>

<div class="col-lg-6 mt-4 ">
<div class="card mx-auto d-block forcard" >
<div>
<img src="compare-icon@3x.png"  class="img-responsive mx-auto d-block" width="13%" height="13%" alt="not found"/>
</div>
<div>
<h5 align="center"><font color="purple"><b>view all cards ></font></b></h5>
</div>
</div>
</div>

<div class="col-lg-6 mt-4 ">
<div class="card mx-auto d-block forcard" >
<div>
<img src="universal-icon@3x_R2.png"  class="img-responsive mx-auto d-block " width="13%" height="13%" alt="not found"/>
</div>
<div >
<h5 align="center"><font color="purple"><b>Use Everywhere ></font></b></h5>
</div>
</div>
</div>

<div class="col-lg-6 mt-4 ">
<div class="card mx-auto d-block forcard" >
<div>
<img src="discount-icon@3x.png"  class="img-responsive mx-auto d-block" width="13%" height="13%" alt="not found"/>
</div>
<div>
<h5 align="center"><font color="purple"><b>Best Disscounts ></b></font></h5>
</div>
</div>
</div>

<div class="col-lg-6 mt-4 ">
<div class="card mx-auto d-block forcard">

<div>
<img src="van_Shift2_3x_R2.png"  class="img-responsive mx-auto d-block " width="13%" height="13%" alt="not found"/>
</div>
<div>

<h5 align="center"><font color="purple"><b>Large Fleet ></font></b></h5>
</div>
</div>
</div>





</div>
</div><--!end of container-->
</div><--!end of bg img-->
</div>










</body>
</html>